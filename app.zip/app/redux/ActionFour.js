import { ActionTypes } from './ActionTypes'

export const ActionFour = {
    set_step_four: (data) => {
        return { type: ActionTypes.SET_STEP_FOUR, payload: data }
    },
	
    
}