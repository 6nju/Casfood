export const ActionTypes = {
    SET_USER_LOGIN: 'SET_USER_LOGIN',
	SET_STEP_FOUR: 'SET_STEP_FOUR',
}