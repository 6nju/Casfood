
const settings = {
  ServiceAddress: 'http://casfood.vn',
  ImageAddress: 'http://casfood.vn'
}

export default settings