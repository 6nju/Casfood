 
import Facebook from './Facebook'

export default Facebook