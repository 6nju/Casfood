 
import InfoMenu from './InfoMenu'

export default InfoMenu