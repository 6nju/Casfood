
import React, { Component } from 'react'
import { View, Text } from 'react-native'

class Test2 extends Component {
    constructor(props) {
        super(props);
        this.state = {
        }
    }

    render() {
        return (
            <View style={{ flex: 1 }}>
                <Text>Test2</Text>
            </View>
        )
    }
}

export default Test2