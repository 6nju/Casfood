 
import AlertInfo from './AlertInfo'

export default AlertInfo