 
import Friends from './Friends'

export default Friends