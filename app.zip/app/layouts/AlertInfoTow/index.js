 
import AlertInfoTow from './AlertInfoTow'

export default AlertInfoTow