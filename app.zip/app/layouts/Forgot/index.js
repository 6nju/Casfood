 
import Forgot from './Forgot'

export default Forgot