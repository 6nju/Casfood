 
import Heavy from './Heavy'

export default Heavy