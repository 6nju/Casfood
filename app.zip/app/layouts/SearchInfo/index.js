 
import SearchInfo from './SearchInfo'

export default SearchInfo